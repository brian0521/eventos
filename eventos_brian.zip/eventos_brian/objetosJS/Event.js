class Event {

	


  constructor(Id, Name,nikname, Description, Participants, DateOfCreation, StartDate, EndDate, CityName, Ubication, Creator) {
    this.Id = Id;
    this.Name = Name;
    this.Description = Description;
    this.Participants = Participants;
    this.DateOfCreation = DateOfCreation;
    this.StartDate = StartDate;
    this.EndDate = EndDate;
    this.CityName = CityName;
    this.Ubication = Ubication;
    this.Creator = Creator;
  }

  /*
var participants = [
	{
		id: 1
	},
	{
		id: 2
	}
	
]


  */
}