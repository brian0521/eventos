class Usuarios {


  constructor(Id, Nombre,Nick, Surname, Email, Password, fechanacimiento, CityName, Address, CP,aficion) {
    this.Id = Id;
    this.Name = Name;
    this.Nick = Nick;
    this.Surname = Surname;
    this.Email = Email;
    this.Password = Password;
    this.fechanacimiento = fechanacimiento;
    this.CityName = CityName;
    this.Address = Address;
    this.CP = CP;
    this.aficion = aficion;
  }

aficion = new Aficion("1", "futbol");


}