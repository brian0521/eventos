class Aficion {


  constructor(Id, Name) {
    this.Id = Id;
    this.Name = Name;
  }



}