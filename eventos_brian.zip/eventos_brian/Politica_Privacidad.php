<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Politica de privacidad</title>
		<link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/listbox.css">
		<!-- Icomoon Icon Fonts -->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Themify Icons -->
		<link rel="stylesheet" href="css/themify-icons.css">
		<!-- Bootstrap  -->
		<link rel="stylesheet" href="css/bootstrap.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Owl Carousel  -->
		<link rel="stylesheet" href="css/owl.carousel.min.css">
		<link rel="stylesheet" href="css/owl.theme.default.min.css">
		<!-- Theme style  -->
		<link rel="stylesheet" href="css/style.css">
		<!-- Modernizr JS -->
		<script src="js/modernizr-2.6.2.min.js"></script>
		<!-- Modernizr JS -->
		<script src="js/listbox.js"></script>
		<!-- Menu -->
	<?php include("Menu.php"); ?>
</head>
<body>
	
			<br>
			<br>
			<br>
			<br>
			<br>

		<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Politica de Privacidad</h2>
					<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
				</div>

</body>
</html>