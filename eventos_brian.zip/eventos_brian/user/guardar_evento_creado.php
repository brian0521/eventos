<?php 
if(isset($_POST['Name_event'])) {




	$Name_event = $_POST['Name_event'];
    $aficion = $_POST['aficion'];
    $Desc_event = $_POST['Desc_event'];
    $Max_personas_event = $_POST['Max_personas_event'];
    $fechainicio = $_POST['fechainicio'];
    $fechafin = $_POST['fechafin'];
    $Adresse = $_POST['Adresse'];
    $Citye = $_POST['Citye'];
    $Provinciae = $_POST['Provinciae'];


}


function GuardarDatos (nom,aficion,descripcion,participantes,fechainicio1,fechafin1,direccion,ciudad,provincia) {




}



 ?>